import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;


public class ReadXMLFileUsingDom {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    try
    {
		
		File xmlDoc = new File("students.xml");
		DocumentBuilderFactory dbFact = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFact.newDocumentBuilder();
		Document doc = dBuilder.parse(xmlDoc);
		
		// read root element
		System.out.println("Root element:" + doc.getDocumentElement().getNodeName());
		
		// read array of students elements, this array is called Nodelist
		NodeList nList = doc.getElementsByTagName("student");
		
	}

    catch (Exception e){
    	
    }
    }
}
